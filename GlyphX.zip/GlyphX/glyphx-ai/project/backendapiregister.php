<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') { exit(0); }

require_once '../db.php';

 $data = json_decode(file_get_contents('php://input'), true);

 $name = $data['name'] ?? null;
 $email = $data['email'] ?? null;
 $password = $data['password'] ?? null;

if (!$name || !$email || !$password) {
    http_response_code(400);
    echo json_encode(["error" => "All fields are required."]);
    exit();
}

// التحقق إذا كان البريد الإلكتروني موجودًا مسبقًا
if (getUserByEmail($email)) {
    http_response_code(409); // Conflict
    echo json_encode(["error" => "Email already exists."]);
    exit();
}

// تشفير كلمة المرور
 $hashed_password = password_hash($password, PASSWORD_DEFAULT);

// إدخال المستخدم الجديد
 $sql = "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)";
 $stmt = $conn->prepare($sql);
 $stmt->bind_param("sss", $name, $email, $hashed_password);

if ($stmt->execute()) {
    http_response_code(201);
    echo json_encode(["success" => "User registered successfully."]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to register user."]);
}

// دالة مساعدة للتحقق من وجود البريد الإلكتروني
function getUserByEmail($email) {
    global $conn;
    $sql = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
?>