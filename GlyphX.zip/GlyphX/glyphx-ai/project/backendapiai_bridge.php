<?php
// هذا هو الجسر الذي ستستدعيه الواجهات الأمامية (صفحات رغد وجنى) للحصول على بيانات من الذكاء الاصطناعي.
// --- الإعدادات ---
// من الأفضل تحديد مسارات التنفيذ في ملف إعدادات مركزي
define('PYTHON_EXECUTABLE', 'python3'); // قد تحتاج لتغييره إلى 'python' حسب السيرفر
define('AI_CORE_SCRIPT_PATH', __DIR__ . '/../../ai/ai_core.py');

// --- إعداد رؤوس CORS للسماح بالاتصال من الواجهات الأمامية ---
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *"); // يمكنك تحديد نطاق معين بدلاً من * للأمان
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// التعامل مع طلبات OPTIONS المسبقة (Preflight) من المتصفح
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// --- التحقق من طريقة الطلب ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["error" => "Only POST requests are allowed."]);
    exit();
}

// --- قراءة والتحقق من مدخلات JSON ---
 $request_data = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "Invalid JSON input."]);
    exit();
}

// --- التحقق من صحة الإجراء ---
 $allowed_actions = ['narration', 'quiz', 'plan'];
 $action = $request_data['action'] ?? null;

if (!in_array($action, $allowed_actions)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid or missing 'action' parameter."]);
    exit();
}

// --- بناء الأمر بأمان ---
 $place_id = $request_data['place_id'] ?? null;
 $lang = $request_data['lang'] ?? 'ar';
 $user_json = isset($request_data['user']) ? json_encode($request_data['user']) : null;

 $command_parts = [PYTHON_EXECUTABLE, AI_CORE_SCRIPT_PATH, '--action', escapeshellarg($action)];

if ($place_id) {
    $command_parts[] = '--place_id';
    $command_parts[] = escapeshellarg($place_id);
}
if ($lang && $lang !== 'ar') {
    $command_parts[] = '--lang';
    $command_parts[] = escapeshellarg($lang);
}
if ($user_json) {
    $command_parts[] = '--user';
    $command_parts[] = escapeshellarg($user_json);
}

 $command = implode(' ', $command_parts);

// --- تنفيذ الأمر والتحقق من الأخطاء ---
 $output = [];
 $return_code = 0;
exec($command . " 2>&1", $output, $return_code);

 $output_string = implode("\n", $output);

// التحقق من كود الخروج (0 يعني النجاح)
if ($return_code !== 0) {
    http_response_code(500); // Internal Server Error
    echo json_encode([
        "error" => "Python script execution failed.",
        "details" => $output_string
    ]);
} else {
    // الأمر نفذ بنجاح، نرجع المخرجات كما هي
    echo $output_string;
}
?>