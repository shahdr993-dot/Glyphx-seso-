<?php
session_start();
session_destroy();
header("Location: ../../login.php"); // إعادة توجيه المستخدم لصفحة الدخول
exit();
?>