-- إنشاء قاعدة البيانات
-- هذا الملف ينشئ قاعدة البيانات والجداول كلها مرة واحدة
CREATE DATABASE IF NOT EXISTS glyphx CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE glyphx;

-- جدول المستخدمين
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `profile_json` JSON, -- استخدام نوع JSON الأفضل إذا كان مدعوماً
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول الأماكن
CREATE TABLE `places` (
  `id` VARCHAR(50) PRIMARY KEY, -- مثلاً 'giza', 'luxor'
  `name_ar` VARCHAR(255) NOT NULL,
  `name_en` VARCHAR(255) NOT NULL,
  `latitude` DECIMAL(10, 8) NOT NULL,
  `longitude` DECIMAL(11, 8) NOT NULL,
  `description_ar` TEXT,
  `description_en` TEXT
);

-- جدول الزيارات (يربط المستخدمين بالأماكن)
CREATE TABLE `visits` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `place_id` VARCHAR(50) NOT NULL,
  `visited_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`place_id`) REFERENCES `places`(`id`) ON DELETE CASCADE
);

-- جدول أوامر IoT (لتخزين الرسائل الموجهة لجهاز ESP32 معين)
CREATE TABLE `iot_commands` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `device_id` VARCHAR(100) NOT NULL,
  `command` VARCHAR(255) NOT NULL, -- مثلاً 'play_audio', 'show_text'
  `content_url` VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `is_delivered` BOOLEAN DEFAULT FALSE,
  -- إضافة فهرس مركب لتسريع عملية البحث عن الأوامر الموجهة لجهاز معين ولم تُسلّم بعد
  INDEX `idx_device_delivered` (`device_id`, `is_delivered`)
);

-- إدخال بيانات أولية للأماكن (مع وصف للاختبار)
INSERT INTO `places` (`id`, `name_ar`, `name_en`, `latitude`, `longitude`, `description_ar`, `description_en`) VALUES
('giza', 'الأهرامات', 'Giza Pyramids', 29.979175, 31.134358, 'مجمع أثري يضم أهرامات الجيزة الكبرى وأبو الهول.', 'An archaeological complex that includes the Great Pyramids of Giza and the Great Sphinx.'),
('luxor', 'الأقصر', 'Luxor', 25.687243, 32.639637, 'تُعرف بمدينة المئة باب وتضم العديد من المعابد والمقابر الفرعونية.', 'Known as the city of a hundred doors, it houses many Pharaonic temples and tombs.');
