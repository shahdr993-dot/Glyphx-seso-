<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>استكشف الأماكن - GlyphX</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary-color: #00d2ff;
            --secondary-color: #3a7bd5;
            --accent-color: #f76b1c;
            --text-color: #ffffff;
            --font-heading: 'Cairo', sans-serif;
            --font-body: 'Tajawal', sans-serif;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: var(--font-body);
            background: #000;
            color: var(--text-color);
            overflow-x: hidden;
        }

        /* Animated Background */
        #particles-js {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -1;
            background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
        }

        /* Navigation */
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            padding: 15px 0;
            background: rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
            transition: all 0.4s ease;
        }
        .navbar .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar .logo {
            font-family: var(--font-heading);
            font-size: 2rem;
            font-weight: 900;
            color: var(--text-color);
            text-decoration: none;
        }
        .navbar .nav-links {
            display: flex;
            list-style: none;
            gap: 25px;
        }
        .navbar .nav-links a {
            color: var(--text-color);
            text-decoration: none;
            font-weight: 600;
            font-family: var(--font-heading);
            transition: color 0.3s ease;
        }
        .navbar .nav-links a:hover { color: var(--primary-color); }

        /* Main Content */
        .main-content {
            padding-top: 100px;
            min-height: 100vh;
        }
        .page-title {
            font-family: var(--font-heading);
            font-size: 3rem;
            font-weight: 900;
            text-align: center;
            margin-bottom: 50px;
            background: linear-gradient(45deg, var(--primary-color), var(--accent-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* Places Grid */
        .places-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 40px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* 3D Place Card */
        .place-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            overflow: hidden;
            cursor: pointer;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
            transform-style: preserve-3d;
            perspective: 1000px;
        }

        .place-card:hover {
            transform: translateY(-10px) rotateX(5deg) rotateY(5deg);
            box-shadow: 0 20px 40px rgba(0, 210, 255, 0.3);
        }

        .place-card-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: transform 0.4s ease;
        }

        .place-card:hover .place-card-image {
            transform: scale(1.1);
        }

        .place-card-content {
            padding: 20px;
        }

        .place-card-content h3 {
            font-family: var(--font-heading);
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--primary-color);
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
            animation: fadeIn 0.3s ease;
        }

        .modal-content {
            background: rgba(20, 20, 40, 0.9);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            margin: 5% auto;
            padding: 30px;
            border-radius: 20px;
            width: 90%;
            max-width: 600px;
            text-align: center;
            animation: slideIn 0.4s ease;
        }

        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideIn { from { transform: translateY(-50px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

        .close {
            color: #aaa;
            float: left;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close:hover { color: var(--primary-color); }

        .modal h2 {
            font-family: var(--font-heading);
            color: var(--primary-color);
            margin-bottom: 20px;
        }

        .modal p {
            line-height: 1.8;
            margin-bottom: 20px;
        }

        .modal .action-btn {
            padding: 12px 25px;
            background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            border-radius: 50px;
            font-family: var(--font-heading);
            font-weight: 700;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .modal .action-btn:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>

    <div id="particles-js"></div>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="user_home.php" class="logo">Glyph<span>X</span></a>
            <ul class="nav-links">
                <li><a href="user_home.php">الرئيسية</a></li>
                <li><a href="explore_places.php">استكشف الأماكن</a></li>
                <li><a href="trip_suggestions.php">اقترح رحلة</a></li>
                <li><a href="profile.php">ملفي الشخصي</a></li>
                <li><a href="backend/api/logout.php">خروج</a></li>
            </ul>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <div class="container">
            <h1 class="page-title">اكتشف عجائب العالم</h1>
            <div class="places-grid" id="placesGrid">
                <!-- Cards will be inserted here by JavaScript -->
            </div>
        </div>
    </main>

    <!-- The Modal -->
    <div id="placeModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2 id="modalTitle">عنوان المكان</h2>
            <p id="modalDescription">...</p>
            <button class="action-btn" id="narrationBtn">استمع للوصف التفاعلي</button>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script>
        // Initialize Particles.js (same as login page)
        particlesJS('particles-js', {
            "particles": { /* ... same config as before ... */ },
            "interactivity": { /* ... same config as before ... */ },
            "retina_detect": true
        });
        
        // DOM Elements
        const placesGrid = document.getElementById('placesGrid');
        const modal = document.getElementById('placeModal');
        const modalTitle = document.getElementById('modalTitle');
        const modalDescription = document.getElementById('modalDescription');
        const narrationBtn = document.getElementById('narrationBtn');
        const closeModal = document.getElementsByClassName('close')[0];

        let currentPlaceId = '';

        // Fetch Places from API
        async function fetchPlaces() {
            try {
                const response = await fetch('backend/api/get_places.php');
                if (!response.ok) throw new Error('Network response was not ok.');
                const places = await response.json();
                displayPlaces(places);
            } catch (error) {
                placesGrid.innerHTML = '<p style="color: red; text-align: center; font-size: 1.5rem;">فشل في تحميل الأماكن. حاول مرة أخرى لاحقًا.</p>';
                console.error('Error fetching places:', error);
            }
        }

        // Display Places in Grid
        function displayPlaces(places) {
            placesGrid.innerHTML = '';
            places.forEach(place => {
                const card = document.createElement('div');
                card.className = 'place-card';
                card.innerHTML = `
                    <img src="https://picsum.photos/seed/${place.id}/400/200.jpg" alt="${place.name_ar}" class="place-card-image">
                    <div class="place-card-content">
                        <h3>${place.name_ar}</h3>
                    </div>
                `;
                card.addEventListener('click', () => openModal(place));
                placesGrid.appendChild(card);
            });
        }

        // Modal Functions
        function openModal(place) {
            currentPlaceId = place.id;
            modalTitle.textContent = place.name_ar;
            modalDescription.textContent = 'جاري تحميل الوصف...';
            modal.style.display = 'block';
            
            // Fetch narration from AI
            fetchNarration(place.id);
        }

        function closeModalFunc() {
            modal.style.display = 'none';
        }

        async function fetchNarration(placeId) {
            try {
                const response = await fetch('backend/api/ai_bridge.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'narration', place_id: placeId, lang: 'ar' })
                });
                const result = await response.json();
                if (result.text) {
                    modalDescription.textContent = result.text;
                } else {
                    modalDescription.textContent = 'لم نتمكن من جلب وصف لهذا المكان حاليًا.';
                }
            } catch (error) {
                modalDescription.textContent = 'حدث خطأ أثناء جلب الوصف.';
                console.error('Error fetching narration:', error);
            }
        }

        narrationBtn.addEventListener('click', () => {
            alert(`هنا سيتم تشغيل الصوت: ${currentPlaceId}_ar.mp3`);
        });

        closeModal.addEventListener('click', closeModalFunc);
        window.addEventListener('click', (event) => {
            if (event.target == modal) {
                closeModalFunc();
            }
        });

        // Initial Load
        document.addEventListener('DOMContentLoaded', fetchPlaces);
    </script>
</body>
</html>