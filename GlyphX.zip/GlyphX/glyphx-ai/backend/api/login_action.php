<?php
// يجب أن يكون هذا السطر في أعلى كل صفحة نستخدم فيها الجلسات
session_start();

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') { exit(0); }

require_once '../db.php';

 $data = json_decode(file_get_contents('php://input'), true);

 $email = $data['email'] ?? null;
 $password = $data['password'] ?? null;

if (!$email || !$password) {
    http_response_code(400);
    echo json_encode(["error" => "Email and password are required."]);
    exit();
}

// جلب بيانات المستخدم من قاعدة البيانات
 $sql = "SELECT id, name, email, password_hash FROM users WHERE email = ?";
 $stmt = $conn->prepare($sql);
 $stmt->bind_param("s", $email);
 $stmt->execute();
 $result = $stmt->get_result();
 $user = $result->fetch_assoc();

if ($user && password_verify($password, $user['password_hash'])) {
    // كلمة المرور صحيحة، إنشاء جلسة
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    
    // إزالة كلمة المرور من النتيجة قبل إرسالها
    unset($user['password_hash']);
    
    echo json_encode(["success" => "Login successful.", "user" => $user]);
} else {
    http_response_code(401); // Unauthorized
    echo json_encode(["error" => "Invalid email or password."]);
}
?>