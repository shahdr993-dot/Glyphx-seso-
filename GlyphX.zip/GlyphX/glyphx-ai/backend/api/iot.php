<!-- هذا هو الملف الذي سيتصل به الروبوت (ESP32) -->
<?php
header("Content-Type: application/json");
// إضافة رؤوس CORS إذا كانت الواجهة الأمامية ستتصل بها مباشرة
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-API-KEY");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once '../db.php';

// --- تحقق بسيط من مفتاح API (مثال) ---
// في نظام حقيقي، يجب أن تكون هذه المفاتيح مخزنة في قاعدة البيانات
 $VALID_API_KEYS = [
    'robot_001_secret_key_abc123',
    'robot_002_secret_key_def456'
];

 $api_key = $_SERVER['HTTP_X_API_KEY'] ?? '';
if (!in_array($api_key, $VALID_API_KEYS)) {
    http_response_code(401); // Unauthorized
    echo json_encode(["error" => "Invalid or missing API Key."]);
    exit();
}

 $device_id = $_GET['device_id'] ?? null;
if (!$device_id) {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "device_id is required."]);
    exit();
}

// --- منطق التقرير (Report) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $report_data = json_decode(file_get_contents('php://input'), true);
    $lat = $report_data['lat'] ?? null;
    $lng = $report_data['lng'] ?? null;
    $event = $report_data['event'] ?? null;

    if (!$lat || !$lng || !$event) {
        http_response_code(400);
        echo json_encode(["error" => "Missing lat, lng, or event in report."]);
        exit();
    }

    // 1. ترجمة الإحداثيات إلى place_id
    $place = findPlaceByLocation($lat, $lng);
    if (!$place) {
        http_response_code(404); // Not Found
        echo json_encode(["error" => "No known place found for these coordinates."]);
        exit();
    }
    $place_id = $place['id'];

    // 2. تسجيل الزيارة (يفترض هنا ربط device_id بـ user_id)
    logVisit($device_id, $place_id);

    // 3. إعداد رد فوري للجهاز
    $response = [
        "place_id" => $place_id,
        "command" => "play_narration",
        "content_url" => "/backend/api/ai_bridge.php?action=narration&place_id=" . urlencode($place_id)
    ];
    
    echo json_encode($response);
}

// --- منطق سحب الأوامر (Poll) ---
elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    global $conn;
    // جلب أقدم أمر لم يتم تسليمه للجهاز
    $sql = "SELECT * FROM iot_commands WHERE device_id = ? AND is_delivered = FALSE ORDER BY created_at ASC LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $device_id);
    $stmt->execute();
    $command = $stmt->get_result()->fetch_assoc();

    if ($command) {
        // تحديث الأمر ليصبح مسلماً
        $update_sql = "UPDATE iot_commands SET is_delivered = TRUE WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("i", $command['id']);
        $update_stmt->execute();
        
        echo json_encode($command);
    } else {
        echo json_encode(["status" => "no_new_commands"]);
    }
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["error" => "Invalid request method."]);
}
?>