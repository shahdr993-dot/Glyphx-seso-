require_once __DIR__ . '/../config.php'; // تضمين ملف الإعدادات
// ... بقية الكود

<?php
// إعدادات الاتصال بقاعدة البيانات
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'glyphx');

// إنشاء الاتصال
 $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// التحقق من الاتصال
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// تعيين ترميز الاتصال لـ UTF-8
 $conn->set_charset("utf8mb4");

// --- دوال مساعدة ---
function getUser($id) {
    global $conn;
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function logVisit($user_id, $place_id) {
    global $conn;
    $sql = "INSERT INTO visits (user_id, place_id) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $place_id);
    return $stmt->execute();
}

function getPlace($id) {
    global $conn;
    $sql = "SELECT * FROM places WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function findPlaceByLocation($lat, $lng, $radius_km = 0.1) {
    global $conn;
    $sql = "SELECT id, (6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) AS distance 
            FROM places HAVING distance < ? ORDER BY distance LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("dddi", $lat, $lng, $lat, $radius_km);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
?>