<?php
session_start();
// التحقق من وجود جلسة للمستخدم
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الرئيسية - GlyphX</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Tajawal', sans-serif; margin: 0; background: #f4f4f9; }
        .navbar { background: #333; color: white; padding: 1rem; display: flex; justify-content: space-between; align-items: center; }
        .navbar a { color: white; text-decoration: none; margin: 0 15px; }
        .hero { text-align: center; padding: 60px 20px; background: linear-gradient(45deg, #007bff, #0056b3); color: white; }
        .hero h1 { font-size: 2.5rem; }
        .actions { display: flex; justify-content: center; gap: 20px; margin-top: 30px; flex-wrap: wrap; }
        .action-card { background: white; border-radius: 8px; padding: 20px; width: 200px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); cursor: pointer; transition: transform 0.2s; }
        .action-card:hover { transform: translateY(-5px); }
        .action-card i { font-size: 2.5rem; color: #007bff; margin-bottom: 15px; }
    </style>
</head>
<body>

    <nav class="navbar">
        <div><strong>GlyphX</strong></div>
        <div>
            <a href="explore_places.php">استكشف الأماكن</a>
            <a href="trip_suggestions.php">اقترح رحلة</a>
            <a href="profile.php">ملفي الشخصي</a>
            <a href="backend/api/logout.php">خروج</a>
        </div>
    </nav>

    <div class="hero">
        <h1>أهلاً بكِ <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>!</h1>
        <p>ماذا تودين أن تفعلي اليوم؟</p>
        <div class="actions">
            <div class="action-card" onclick="goToPage('explore_places.php')">
                <i class="fas fa-map-marked-alt"></i>
                <h3>استكشف الأماكن</h3>
            </div>
            <div class="action-card" onclick="goToPage('trip_suggestions.php')">
                <i class="fas fa-route"></i>
                <h3>خطط لرحلة</h3>
            </div>
            <div class="action-card" onclick="goToPage('emergency.php')">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>الطوارئ</h3>
            </div>
        </div>
    </div>

    <script>
        function goToPage(page) {
            window.location.href = page;
        }
    </script>
</body>
</html>