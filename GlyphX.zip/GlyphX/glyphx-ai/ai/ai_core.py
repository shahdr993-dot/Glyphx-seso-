import argparse
import json
import os
#عقل المشروع
# --- Mock Data ---
MOCK_DATA = {
    "giza": {
        "narration_ar": "أهلاً بك في هضبة الجيزة، موطن الأهرامات الثلاثة العظيمة. هذه التحفة المعمارية القديمة شاهد على عظمة الحضارة المصرية.",
        "narration_en": "Welcome to the Giza Plateau, home of the Great Pyramids. This ancient architectural marvel is a testament to the grandeur of Egyptian civilization.",
        "quiz": {
            "question": "كم هرماً رئيسياً في هضبة الجيزة؟",
            "options": ["واحد", "اثنان", "ثلاثة", "أربعة"],
            "answer": "ثلاثة"
        }
    },
    "luxor": {
        "narration_ar": "مرحباً في الأقصر، مدينة المئة باب. تجول في معابد الكرنك ووادي الملوك لتكتشف أسرار الفراعنة.",
        "narration_en": "Welcome to Luxor, the city of a hundred doors. Explore the temples of Karnak and the Valley of the Kings to discover the secrets of the Pharaohs.",
        "quiz": {
            "question": "ما هو اسم الوادي الشهير الذي يضم مقابر الفراعنة في الأقصر؟",
            "options": ["وادي النيل", "وادي الملوك", "وادي الريان", "وادي الحيتان"],
            "answer": "وادي الملوك"
        }
    }
}

def generate_narration(place_id, lang="ar"):
    print(f"AI Core: Generating narration for {place_id} in {lang}")
    place_data = MOCK_DATA.get(place_id)
    if not place_data:
        return {"error": "Place not found"}

    text_key = f"narration_{lang}"
    text = place_data.get(text_key, "Narration not available for this language.")
    
    audio_filename = f"{place_id}_{lang}.mp3"
    audio_path = f"/backend/upload/audio/{audio_filename}"
    
    os.makedirs(os.path.dirname(audio_path), exist_ok=True)
    with open(f".{audio_path}", "w") as f:
        f.write(f"Mock audio content for {audio_filename}")

    return {"text": text, "audio": audio_path}

def generate_quiz(place_id):
    print(f"AI Core: Generating quiz for {place_id}")
    place_data = MOCK_DATA.get(place_id)
    if not place_data or "quiz" not in place_data:
        return {"error": "Quiz not found for this place"}
    
    return place_data["quiz"]

def plan_trip(user_profile):
    print(f"AI Core: Planning trip for user {user_profile.get('name')}")
    return {"suggested_places": ["giza", "luxor"], "duration_days": 5}

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AI Core for GlyphX")
    parser.add_argument("--action", required=True, choices=["narration", "quiz", "plan"])
    parser.add_argument("--place_id", help="ID of the place")
    parser.add_argument("--lang", default="ar", help="Language code (e.g., ar, en)")
    parser.add_argument("--user", help="User profile JSON string")
    
    args = parser.parse_args()

    result = {}
    if args.action == "narration":
        result = generate_narration(args.place_id, args.lang)
    elif args.action == "quiz":
        result = generate_quiz(args.place_id)
    elif args.action == "plan":
        if args.user:
            user_profile = json.loads(args.user)
            result = plan_trip(user_profile)
        else:
            result = {"error": "User profile is required for trip planning"}

    print(json.dumps(result))