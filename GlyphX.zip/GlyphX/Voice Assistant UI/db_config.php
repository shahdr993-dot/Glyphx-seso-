<?php
// إعدادات الاتصال بقاعدة البيانات
 $host = 'localhost';
 $dbname = 'glyphx_db'; // تأكد من اسم قاعدة البيانات صح
 $user = 'root';
 $pass = ''; // كلمة مرور root في XAMPP تكون فاضية افتراضيًا
 $charset = 'utf8mb4';

// Data Source Name
 $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

// خيارات PDO
 $options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // إنشاء اتصال PDO
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // في حال فشل الاتصال، اعرض رسالة خطأ
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
?>