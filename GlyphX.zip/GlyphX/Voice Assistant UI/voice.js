// أضف هذا الكود في ملف JavaScript الخاص بك أو في نهاية صفحتك داخل وسم <script>
document.addEventListener('DOMContentLoaded', function() {
    // عناصر واجهة المساعد
    const voiceAssistant = document.getElementById('voiceAssistant');
    const toggleBtn = document.getElementById('toggleAssistant');
    const closeBtn = document.getElementById('closeAssistant');
    const voiceInputBtn = document.getElementById('voiceInputBtn');
    const textInput = document.getElementById('textInput');
    const sendTextBtn = document.getElementById('sendTextBtn');
    const messagesContainer = document.getElementById('assistantMessages');
    
    // متغيرات للتعرف على الصوت
    let recognition;
    let isListening = false;
    
    // التحقق من دعم المتصفح للتعرف على الصوت
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRecognition();
        recognition.lang = 'ar-SA'; // اللغة العربية
        recognition.continuous = false;
        recognition.interimResults = false;
        
        recognition.onstart = function() {
            isListening = true;
            voiceInputBtn.classList.add('listening');
            voiceInputBtn.innerHTML = '<i class="fas fa-microphone-slash"></i><span>جاري الاستماع...</span>';
        };
        
        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            textInput.value = transcript;
            sendUserMessage(transcript);
        };
        
        recognition.onerror = function(event) {
            console.error('خطأ في التعرف على الصوت:', event.error);
            addAssistantMessage('عذرًا، لم أتمكن من فهم ما قلته. يرجى المحاولة مرة أخرى.');
            stopListening();
        };
        
        recognition.onend = function() {
            stopListening();
        };
    } else {
        console.log('المتصفح لا يدعم التعرف على الصوت');
        voiceInputBtn.style.display = 'none';
    }
    
    // وظائف التحكم في واجهة المساعد
    toggleBtn.addEventListener('click', function() {
        voiceAssistant.classList.add('active');
    });
    
    closeBtn.addEventListener('click', function() {
        voiceAssistant.classList.remove('active');
    });
    
    voiceInputBtn.addEventListener('click', function() {
        if (isListening) {
            stopListening();
        } else {
            startListening();
        }
    });
    
    sendTextBtn.addEventListener('click', function() {
        const text = textInput.value.trim();
        if (text) {
            sendUserMessage(text);
            textInput.value = '';
        }
    });
    
    textInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const text = textInput.value.trim();
            if (text) {
                sendUserMessage(text);
                textInput.value = '';
            }
        }
    });
    
    function startListening() {
        if (recognition) {
            recognition.start();
        }
    }
    
    function stopListening() {
        if (recognition && isListening) {
            recognition.stop();
        }
        isListening = false;
        voiceInputBtn.classList.remove('listening');
        voiceInputBtn.innerHTML = '<i class="fas fa-microphone"></i><span>اضغط للتحدث</span>';
    }
    
    // إرسال رسالة المستخدم ومعالجة الرد
    function sendUserMessage(message) {
        addMessage(message, 'user');
        
        // إرسال الرسالة إلى الخادم للحصول على رد
        fetch('voice_assistant.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message,
                user_id: getCurrentUserId() // دالة للحصول على معرف المستخدم الحالي
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                addAssistantMessage(data.response);
                speakText(data.response); // نطق الرد صوتياً
            } else {
                addAssistantMessage('عذرًا، حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            addAssistantMessage('عذرًا، حدث خطأ في الاتصال بالخادم. يرجى المحاولة مرة أخرى.');
        });
    }
    
    // إضافة رسالة إلى واجهة المحادثة
    function addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        messageDiv.innerHTML = `<p>${text}</p>`;
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    // اختصار لإضافة رسالة المساعد
    function addAssistantMessage(text) {
        addMessage(text, 'assistant');
    }
    
    // تحويل النص إلى كلام (Text-to-Speech)
    function speakText(text) {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'ar-SA';
            utterance.rate = 0.9; // سرعة النطق
            
            // البحث عن صوت عربي
            const voices = window.speechSynthesis.getVoices();
            for (let i = 0; i < voices.length; i++) {
                if (voices[i].lang.includes('ar')) {
                    utterance.voice = voices[i];
                    break;
                }
            }
            
            window.speechSynthesis.speak(utterance);
        } else {
            console.log('المتصفح لا يدعم تحويل النص إلى كلام');
        }
    }
    
    // الحصول على معرف المستخدم الحالي (يجب تعديلها حسب نظامك)
    function getCurrentUserId() {
        // إذا كان معرف المستخدم مخزناً في متغير جافاسكريبت
        if (typeof currentUserId !== 'undefined') {
            return currentUserId;
        }
        
        // إذا كان معرف المستخدم مخزناً في جلسة PHP وتم تمريره إلى الصفحة
        const userIdElement = document.getElementById('current-user-id');
        if (userIdElement) {
            return userIdElement.value;
        }
        
        // كحل أخير، يمكنك استخدام ملف تعريف الارتباط أو طريقة أخرى
        return null;
    }
    
    // تحميل الأصوات المتاحة
    if ('speechSynthesis' in window) {
        window.speechSynthesis.onvoiceschanged = function() {
            // تم تحميل الأصوات
        };
        window.speechSynthesis.getVoices();
    }
});

<script src="voice.js"></script> 