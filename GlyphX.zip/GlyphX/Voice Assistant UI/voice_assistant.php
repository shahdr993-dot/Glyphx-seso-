<?php
require_once 'db_config.php';
require_once 'ai_bridge.php'; 

session_start();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// التحقق من تسجيل دخول المستخدم
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'response' => 'يرجى تسجيل الدخول لاستخدام المساعد الصوتي']);
    exit;
}

// الحصول على الرسالة
$data = json_decode(file_get_contents('php://input'), true);
$message = $data['message'] ?? '';
$userId = $_SESSION['user_id'];

if (empty($message)) {
    echo json_encode(['success' => false, 'response' => 'لم أتمكن من فهم طلبك']);
    exit;
}

try {
    // الحصول على بيانات المستخدم للترحيب الشخصي
    $stmt = $pdo->prepare("SELECT username, name FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $name = $user['name'] ?? 'مستخدم';
    
    // تحليل الرسالة والرد
    $response = generateResponse($message, $userId, $user['username'], $name);
    
    // تسجيل المحادثة
    logConversation($userId, $message, $response);
    
    echo json_encode(['success' => true, 'response' => $response]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'response' => 'حدث خطأ في النظام']);
}

// --- الدالة الأساسية لإدارة الردود والأوامر ---
function generateResponse($message, $userId, $username, $name) {
    global $pdo;

    // ذاكرة بسيطة للمحادثة
    $_SESSION['last_user_message'] = $message;
    $previousMessage = $_SESSION['last_ai_response'] ?? 'بداية المحادثة';

    // 1. فحص أوامر الروبوت (اذهب، توقف)
    $commandResult = handleRobotCommand($message, $name);
    if ($commandResult) {
        $_SESSION['last_ai_response'] = $commandResult;
        return $commandResult;
    }

    // 2. الردود الفورية (ترحيب/شكر)
    if (preg_match("/(مرحبا|أهلا|هلا|سلام)/i", $message)) return "يا أهلاً بك يا {$name}! أنا GlyphX، مرشدك الذكي.";

    // 3. البحث عن أماكن سياحية
    if (preg_match("/(أخبرني عن|ما هو|ما هي|حدثني عن)/i", $message)) {
        $placeName = extractPlaceName($message);
        $stmt = $pdo->prepare("SELECT narration FROM places WHERE name LIKE ?");
        $stmt->execute(["%$placeName%"]);
        $place = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($place) return $place['narration'];
    }

    // 4. الذكاء الاصطناعي للمحادثات المفتوحة
    try {
        $aiBridge = new AIBridge();
        $context = "أنت GlyphX، مساعد ذكي ومرح. المستخدم هو {$name}. رد بلهجة مصرية رقيقة.";
        $result = $aiBridge->generateCustomResponse($message, $context);
        if ($result['success']) {
            $_SESSION['last_ai_response'] = $result['response'];
            return $result['response'];
        }
    } catch (Exception $e) { }

    return "معلش يا {$name}، ممكن توضح سؤالك أكتر؟";
}

// --- دالة التحكم في الروبوت GlyphX ---
function handleRobotCommand($message, $userName) {
    global $pdo;
    $robotId = 1; 

    // أمر الحركة
    if (preg_match("/(اذهب إلى|روح ل|اتجه إلى)/i", $message, $matches)) {
        $placeName = trim(str_ireplace($matches[0], '', $message));
        $stmt = $pdo->prepare("SELECT id, name FROM places WHERE name LIKE ?");
        $stmt->execute(["%$placeName%"]);
        $place = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($place) {
            $updateStmt = $pdo->prepare("UPDATE robots SET target_place_id = ?, status = 'moving' WHERE id = ?");
            $updateStmt->execute([$place['id'], $robotId]);
            return "تم يا {$userName}! GlyphX بيتحرك دلوقتي لـ {$place['name']}.";
        }
    }
    
    // أمر التوقف
    if (preg_match("/(توقف|قف|وقف)/i", $message)) {
        $updateStmt = $pdo->prepare("UPDATE robots SET status = 'stopped' WHERE id = ?");
        $updateStmt->execute([$robotId]);
        return "حاضر، أنا وقفت مكاني.";
    }

    return false;
}

function extractPlaceName($message) {
    $keywords = ['أخبرني عن', 'ما هو', 'ما هي', 'حدثني عن'];
    $placeName = $message;
    foreach ($keywords as $keyword) {
        if (stripos($message, $keyword) !== false) {
            $placeName = trim(str_ireplace($keyword, '', $message));
            break;
        }
    }
    return preg_replace('/[؟!.,]/', '', $placeName);
}

function logConversation($userId, $userMessage, $assistantResponse) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO voice_conversations (user_id, user_message, assistant_response) VALUES (?, ?, ?)");
    $stmt->execute([$userId, $userMessage, $assistantResponse]);
}
?>