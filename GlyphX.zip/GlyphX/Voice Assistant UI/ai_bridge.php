<?php
require_once 'db_config.php';

class AIBridge {
    private $pythonScriptPath;
    
    public function __construct($pythonScriptPath = 'ai_core.py') {
        // تأكد إن المسار ده صحيح لمكان ملف البايثون بتاعك
        $this->pythonScriptPath = $pythonScriptPath;
    }
    
    public function generateNarration($placeId, $language = 'ar') {
        // ... (كود الدالة كما هو) ...
    }
    
    public function generateQuiz($placeId, $difficulty = 'medium') {
        // ... (كود الدالة كما هو) ...
    }
    
    // الدالة المهمة للردود المفتوحة
    public function generateCustomResponse($message, $context = '') {
        try {
            // بناء الأمر اللي هيتنفذ في الطرفية (CMD)
            // لاحظ إننا بنمرر الـ prompt كله كـ argument
            $prompt = $context . "\n\nالمستخدم يسأل: " . $message . "\n\nالرد:";
            $escaped_prompt = escapeshellarg($prompt);
            $command = "python {$this->pythonScriptPath} --action custom --prompt {$escaped_prompt}";
            
            // تنفيذ الأمر وجلب الناتج
            $output = shell_exec($command);
            
            // تحليل الناتج اللي رجع كـ JSON
            $result = json_decode($output, true);
            
            if (!$result || !isset($result['text'])) {
                return ['error' => 'فشل في تحليل نتيجة الذكاء الاصطناعي'];
            }
            
            return ['success' => true, 'response' => $result['text']];
        } catch (Exception $e) {
            error_log("AI Bridge Error: " . $e->getMessage());
            return ['error' => $e->getMessage()];
        }
    }
}
?>