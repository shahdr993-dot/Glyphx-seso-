import openai
import json
import argparse

# ⭐⭐⭐⭐⭐ مهم جداً: ضع مفتاح API الخاص بـ OpenAI هنا ⭐⭐⭐⭐⭐
openai.api_key = "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"

def generate_narration(place_name, place_info, language="ar"):
    """
    توليد سرد ذكي للأماكن السياحية
    """
    prompt = f"""
    قم بإنشاء سرد تاريخي شيق ومفصل للمكان السياحي التالي:
    
    اسم المكان: {place_name}
    معلومات أساسية: {place_info}
    
    يجب أن يكون السرد:
    - باللغة {language}
    - جذاب ومثير للاهتمام
    - لا يزيد عن 300 كلمة
    - يحتوي على حقائق تاريخية دقيقة
    """
    try:
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=500,
            temperature=0.7
        )
        return {"text": response.choices[0].text.strip()}
    except Exception as e:
        print(f"Error generating narration: {e}")
        return {"text": f"عذرًا، حدث خطأ في توليد السرد للمكان: {place_name}"}

def generate_quiz(place_name, difficulty="medium"):
    """
    توليد اختبار قصير بناءً على المعلومات عن المكان
    """
    prompt = f"""
    قم بإنشاء اختبار قصير من 5 أسئلة اختيار من متعدد عن المكان التالي:
    
    اسم المكان: {place_name}
    مستوى الصعوبة: {difficulty}
    
    يجب أن يكون الاختبار باللغة العربية ويحتوي على:
    - 5 أسئلة
    - 4 خيارات لكل سؤال
    - الإجابة الصحيحة محددة بوضوح
    """
    try:
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=800,
            temperature=0.5
        )
        return {"text": response.choices[0].text.strip()}
    except Exception as e:
        print(f"Error generating quiz: {e}")
        return {"text": f"عذرًا، حدث خطأ في توليد الاختبار للمكان: {place_name}"}

def generate_custom_response(prompt, language="ar"):
    try:
        # الموديل الجديد والأسرع
        response = openai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300,
            temperature=0.7
        )
        return {"text": response.choices[0].message.content.strip()}
    except Exception as e:
        return {"text": "عذرًا، حدث خطأ في التواصل مع الذكاء الاصطناعي"}
# ⭐⭐⭐⭐⭐ الجزء اللي بيخلي الملف يشتغل من سطر الأوامر ⭐⭐⭐⭐⭐
if __name__ == "__main__":
    # بناء "مفسر الأوامر" عشان نفهم إيه اللي PHP بتبعتوله
    parser = argparse.ArgumentParser(description="AI Core for GlyphX")
    parser.add_argument('--action', required=True, choices=['narration', 'quiz', 'custom'], help="نوع الإجراء المطلوب")
    parser.add_argument('--place', help="اسم المكان (لـ narration و quiz)")
    parser.add_argument('--info', help="معلومات عن المكان (لـ narration)")
    parser.add_argument('--prompt', help="النص الكامل للمحادثة (لـ custom)")
    parser.add_argument('--difficulty', default='medium', help="مستوى الصعوبة (لـ quiz)")
    parser.add_argument('--lang', default='ar', help="الغة")
    
    # قراءة الأوامر اللي اتبعتت
    args = parser.parse_args()
    
    result = {}
    
    # تنفيذ الدالة المطلوبة بناءً على الأمر
    if args.action == 'narration':
        result = generate_narration(args.place, args.info, args.lang)
    elif args.action == 'quiz':
        result = generate_quiz(args.place, args.difficulty)
    elif args.action == 'custom':
        result = generate_custom_response(args.prompt, args.lang)
    
    # طباعة الناتج كـ JSON عشان PHP تقدر تقراه
    print(json.dumps(result, ensure_ascii=False))
